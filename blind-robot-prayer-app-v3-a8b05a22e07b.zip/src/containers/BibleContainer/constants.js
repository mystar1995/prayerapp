export const SET_CURRENT_BOOK = 'BibleContainer/SET_CURRENT_BOOK';
export const SET_CURRENT_CHAPTER = 'BibleContainer/SET_CURRENT_CHAPTER';
export const SET_BOOK_CONTENT = 'BibleContainer/SET_BOOK_CONTENT';
export const SET_LOADING = 'BibleContainer/SET_LOADING';
export const SET_NEXT_CHAPTER_TITLE = 'BibleContainer/SET_NEXT_CHAPTER_TITLE';
export const SET_PREV_CHAPTER_TITLE = 'BibleContainer/SET_PREV_CHAPTER_TITLE';
export const SET_NEXT_ENABLED = 'BibleContainer/SET_NEXT_ENABLED';
export const SET_PREV_ENABLED = 'BibleContainer/SET_PREV_ENABLED';

export const SET_USER = 'AuthContainer/SET_USER';
export const UPDATE_AUTH_FIELD = 'AuthContainer/UPDATE_AUTH_FIELD';
export const UPDATE_USER_FIELD = 'AuthContainer/UPDATE_USER_FIELD';
export const SET_ACCOUNT_LOADING = 'AuthContainer/SET_ACCOUNT_LOADING';
export const SET_UPDATE = 'AuthContainer/SET_UPDATE';
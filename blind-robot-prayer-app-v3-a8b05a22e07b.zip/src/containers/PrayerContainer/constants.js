export const SET_DAILY_PRAYER = 'PrayerContainer/SET_DAILY_PRAYER';
export const SET_LOADING_DAILY_PRAYER =
	'PrayerContainer/SET_LOADING_DAILY_PRAYER';

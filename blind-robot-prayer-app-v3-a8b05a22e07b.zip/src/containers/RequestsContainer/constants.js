export const SET_PRAYER_REQUESTS = 'RequestsContainer/SET_PRAYER_REQUESTS';
export const UPDATE_PRAYER_REQUEST = 'RequestsContainer/UPDATE_PRAYER_REQUEST';
export const SET_END_OF_REQUESTS = 'RequestsContainer/SET_END_OF_REQUESTS';
export const EDIT_PRAYER_REQUEST = 'RequestsContainer/EDIT_PRAYER_REQUEST';
export const RESET_PRAYER_REQUEST = 'RequestsContainer/RESET_PRAYER_REQUEST';
export const SET_LOADING = 'RequestsContainer/SET_LOADING';
export const SET_MODAL_VISIBLE = 'RequestsContainer/SET_MODAL_VISIBLE';
export const SET_FILTER_DISTANCE = 'RequestsContainer/SET_FILTER_DISTANCE';

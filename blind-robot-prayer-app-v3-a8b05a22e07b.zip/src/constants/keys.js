export const webClientId =
	'1019701435873-tpnfsgotmqjqhjibsc2ob5r06rnr970t.apps.googleusercontent.com';

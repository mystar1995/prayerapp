export const credentials = {
	clientId:
		'1019701435873-aduphgfa6vigao6iv1b97odjvjpqm7dv.apps.googleusercontent.com',
	appId: 'com.bitloft.prayerapp',
	apiKey: 'AIzaSyBCMA9-1iV-VC7fApFVTG-t0-vvz3RQCrc',
	databaseURL: 'https://prayer-app-v2.firebaseio.com',
	storageBucket: 'gs://prayer-app-v2.appspot.com/',
	messagingSenderId: '1019701435873',
	projectId: 'prayer-app-v2',
};

export const config = {
	name: 'SECONDARY_APP',
};
